/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : stadium.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __STADIUM_H
#define __STADIUM_H
#include <string>
 
class Stadium
{
    private:
        // string name;
    public:
        Stadium();
        ~Stadium();
        Stadium(const Stadium&);
        Stadium& operator= (Stadium&);

        // string GetName();
};

#endif // __STADIUM_H