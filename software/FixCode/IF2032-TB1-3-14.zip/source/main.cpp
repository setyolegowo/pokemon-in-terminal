/* ************************************************************************** */
/*                                PROGRAM UTAMA                               */
/* ************************************************************************** */

#include "pokeranch.h"

int main()
{
    /* *** KAMUS *** */
    PokeRanch Pokeranch;
    
    /* *** ALGORITMA *** */
    Pokeranch.Start();
    // Pokeranch.LookTable();
    
    return 0;
}