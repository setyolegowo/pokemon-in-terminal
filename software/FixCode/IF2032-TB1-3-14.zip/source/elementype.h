/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : elementype.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __ELEMENTYPE_H
#define __ELEMENTYPE_H

enum ElemenType {
	_NULL,
    Psychic,
    Fight,
    Normal,
    Water,
    Grass,
    Ground,
    Flying,
    Ice,
    Electric,
    Dragon
};

#endif // __ELEMENTYPE_H