/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : combinatorium.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 //Created by : Fawwaz Muhammad

 #include "store.h"
 #include <iostream>

Store::Store(){
	// name="Store";
}
Store::~Store(){}
Store::Store(const Store& S){
	// name=S.name;
}
Store& Store::operator= (Store&){
	// name=S.name;
	// return *this;
}
void Store::PrintImage(){}
unsigned short Store::Buy(unsigned short){}
unsigned short Store::Sell(unsigned short){}

// string GetName(){return name;}