/* ************************************************************************** */
/*                                MAIN SKILL                                  */
/* ************************************************************************** */

#include "listofskill.h"
#include "skill.h"

int main()
{
    /* *** KAMUS *** */
    ListOfSkill LISTSkill;
    
    /* *** ALGORITMA *** */
    LISTSkill.ReadFromFile();
    
    return 0;
}