// Test case main file program untuk outer area

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "outerarea.h"

using namespace std;

int main()
{
	OuterArea O;
	char CC;
	O.RandomMonster();
	O.RandomUnstapable();
	// OuterArea::area[1]==false;
	do
	{
		cin >>CC;
		
		
		O.PrintMap();
		switch(CC)
		{
			case 'w':
				O.UpdatePlayerPosition(1,1);
				// if (O.UpdatePlayerPosition(1,1))
				// {
				// 	printf("Berhasil dipindahkan");
				// }else{
				// 	printf("Gagal dipindahkan ");
				// }
				break;
			case 'a':
				O.UpdatePlayerPosition(4,1);
				break;
			case 's':
				O.UpdatePlayerPosition(3,1);
				break;
			case 'd':
				O.UpdatePlayerPosition(2,1);
				break;
			default:
				break;
			system("cls");
		}
		O.DrawPlayerPosition();
	} while (CC!='c');

	printf(" ");
	return 0;
}