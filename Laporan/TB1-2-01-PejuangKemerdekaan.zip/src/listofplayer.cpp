/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : listofplayer.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */

#include <list>
#include <fstream>
#include <stdio.h>
#include "listofplayer.h"

using namespace std;

ListOfPlayer::ListOfPlayer() {
}

ListOfPlayer::~ListOfPlayer() {
    tabelPlayer.clear();
    tabelPlayer.~list();
}

ListOfPlayer::ListOfPlayer(const ListOfPlayer& LOP) {
    
}

ListOfPlayer& ListOfPlayer::operator= (ListOfPlayer& LOP) {
    return *this;
}

bool ListOfPlayer::IsOnTable(char * _Name)
{
    return false; // Sementara!!!
}

void ListOfPlayer::ReadFromFile()
{
    ifstream myfile("player/player.txt",ifstream::in);
    
    tabelPlayer.clear();
    if(myfile.is_open()) {
        while(myfile.good())
        {
            char cur_stream[200];
            string nama;
            
            myfile.getline(cur_stream,100);
            int i = 0;
            while(cur_stream[i] != ';')
            {
                nama+=cur_stream[i];
                i++;
            }
            if(i > 0)
                tabelPlayer.push_back(nama);
        }
    } else
        throw(2);
    
    myfile.close();
}
void ListOfPlayer::ReadPlayer(Player * _Player, char * _Name)
// Prekondisi, _Name ada dalam tabelPlayer.
{
    
}
void ListOfPlayer::MakePlayer(Player * _Player, char * _Name)
// Prekondisi: panjang char * terdefinisi (dapat langsung diaplikasikan ke fungsi ini)
{
    char PlayerFile[22] = "player/player-";
    char PlayerItem[18] = "item/item-";
    char PlayerMonster[24] = "monster/monster-";
    char PlayerParty[22] = "monster/party-";
    ofstream myfile;
    
    // Membuat nama file
    int i = 0;
    while(_Name[i] != '\0')
    {
        PlayerFile[i + 14] = _Name[i];
        PlayerItem[i + 10] = _Name[i];
        PlayerMonster[i + 16] = _Name[i];
        PlayerParty[i + 14] = _Name[i];
        i++;
    }
    
    // ::: Membuat data Player :::
    // -> Mengisi _Player
    _Player->ChangeName(_Name);
    _Player->IncMoney(7500);
    // -> Membuat file data
    myfile.open(PlayerFile,ofstream::out);
    if(myfile.is_open()) {
        myfile << "0 0 7500 0 0;"; // SumOfDays, DayOrNight, Money, Win, Lose
    }
    myfile.close();
    
    // ::: Membuat data Item
    // -> Membuat file data
    myfile.open(PlayerItem,ofstream::out);
    if(myfile.is_open())
        myfile << ";"; // NoItem, Qty
    myfile.close();
    
    // ::: Membuat data Monster
    // -> Membuat file daftar monster
    myfile.open(PlayerMonster,ofstream::out);
    if(myfile.is_open())
        myfile << ";"; // MonsterNumber, Name, CurAge, CurLevel, CurExp, TotalExp, IncHP, HP, IncAttack, IncDefense, IncSpeed, {Skill}, {PPOfSkill}, Effect
    myfile.close();
    // -> Membuat file daftar party
    myfile.open(PlayerParty,ofstream::out);
    if(myfile.is_open())
        myfile << "0 0 0 0 0 0;"; // Number of monster
    myfile.close();
    
    // ::: UPDATE DATA PLAYER :::
    remove("player/player.txt");
    myfile.open("player/player.txt",ofstream::out);
    std::list<string>::iterator it;
    
    it = tabelPlayer.begin();
    if(myfile.is_open()) {
        while(it != tabelPlayer.end())
        {
            myfile << *it;
            myfile << ";\n";
        }
    }
    myfile.close();
}