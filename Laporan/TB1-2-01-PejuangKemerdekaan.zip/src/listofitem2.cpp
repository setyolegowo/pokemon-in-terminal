/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : listofitem.cpp
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */

#include <iostream>
#include <fstream>
#include "listofitem2.h"
using std::ifstream;
using std::string;


ListOfItem::ListOfItem() : MaxItemList(50) {
	tabelItem = new Item[MaxItemList];
    nItem = 0;

}

ListOfItem::~ListOfItem() {
    delete [] tabelItem;
	nItem = 0;
}

ListOfItem::ListOfItem(const ListOfItem& LOP) : MaxItemList(LOP.MaxItemList) {
	int i;
    nItem = LOP.nItem;
    tabelItem = new Item[MaxItemList];
    for(i = 0; i < nItem; i++)
        tabelItem[i] = LOP.tabelItem[i];
}

ListOfItem& ListOfItem::operator= (const ListOfItem& LOP) {
    int i;
        
	delete [] tabelItem;
	nItem = LOP.nItem;
	tabelItem = new Item[MaxItemList];
    for(i = 0; i < nItem; i++)
        tabelItem[i] = LOP.tabelItem[i];

    return *this;
}

int ListOfItem::GetNItem() {
	return nItem;

}

void ListOfItem::ReadFromFile()
{
    ifstream myfile("item/item.txt");
    
	delete [] tabelItem;
    nItem = 0;
    tabelItem = new Item[MaxItemList];
    if(myfile.is_open()) {
        while(myfile.good())
        {
            // char cur_stream[100];
			string cur_stream;
            char nama[12];
            int i = 0;
            unsigned char no;
            
            getline(myfile,cur_stream);
            // => Get Number of item
            no = 0;
            while(cur_stream[i] != ' ')
            {
                no = 10*no + (cur_stream[i] - '0');
                i++;
            }
            i++; // Lewati karakter spasi
            
            // => Get nama item
            int j = 0;
            while(cur_stream[i] != ' ')
            {
                nama[j] = cur_stream[i];
                i++;
                j++;
            }
            while(j < 12) {
                nama[j] = '\0';
                j++;
            }
            i++; // Lewati karakter spasi
            
            // => Get Type
            int n = cur_stream[i] - '0';
            i++;
            i++;
            
            // => Get Price
            int Price = 0;
            while(cur_stream[i] != ' ') {
                Price = 10*Price + (cur_stream[i] - '0');
                i++;
            }
            i++;
            
            // => Get Value
            int Value = 0;
            while(cur_stream[i] != ',') {
                Value = 10*Value + (cur_stream[i] - '0');
                i++;
            }
            
            // Masukkan ke tipe item
            Item tItem(no,nama,n,Price,Value);
            
            // Masukkan ke list
            // tabelItem.push_back(tItem);
			tabelItem[nItem]=tItem;
			nItem++;
        }
    } else
        throw(2);
    
    myfile.close();
}