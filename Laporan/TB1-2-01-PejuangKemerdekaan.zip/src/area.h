/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : areas.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */


#ifndef __AREA_H
#define __AREA_H

#include "point.h"

class Area
{
    private:
        // MaxUnstapablePoint
        const int MaxUnstapablePoint;
        
        unsigned char Width;
        unsigned char Height;
        unsigned char PlayerPositionPlace;

        
        
        // Point *UnstapableP;
        // unsigned char *UnstapableActive;
        
        
    public:
        Area();
        ~Area();
        Area(const Area&);
        Area &operator=(Area&);

        unsigned char *area;//sengaja ditaruh di public agar bisa telanjang bugil dan diakses dari luar
        // Area adalah array dari boolean yang menggambarkan kondisi peta dari atas
        // indeks 0 menyatakan kondisi koordinat di titik paling kiri atas, dan indeks ke-Height*Width
        // menyatakan kondisi koordinat di paling kanan bawah. 
        // Jika suatu indeks bernilai 1 berarti unstepable dan jika 0 berarti stepable
        // misal area[0] bernilai 1, maka koordinat titik paling kiri atas tidak bisa di step
        Point PlayerPosition;

        unsigned char GetWidth();
        unsigned char GetHeight();
        void SetWidth(unsigned char);
        void SetHeight(unsigned char);
        int ConvertPointToIdxArea(Point&);
        Point ConvertIdxAreaToPoint(int);
        int GetMaxUnstapablePoint() const;
        bool UpdatePlayerPosition(unsigned char,unsigned char);
        //Parameter 1 adalah arah(direction) dan parameter 2 adalah jumlah stepsnya
        //Parameter 1 bernilai 1 => move direction ke atas
        //Parameter 1 bernilai 2 => move direction ke kanan
        //Parameter 1 bernilai 3 => move direction ke bawah
        //Parameter 1 bernilai 4 => move direction ke kiri
        //Parameter 2 berniali 0..Width
        //Return value 1 jika valid moves
        //Return Value 0 jika invalid moves : pindah ke unstapable area atau keluar layar

        // bool* GetArea();
        // void SetArea(bool Area);
};
// __AREA_H
#endif 