/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : playermonster.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#include "monster.h"

//Default constructor belum dibuat
Monster::Monster(void) : MaxSpesiesLength(60), MaxMove(4) {
		Age = 0;
        MonsterNumber = 0;
        Elemen0 = Normal;
        Elemen1 = Normal;
        HP = 0;
        Attack = 0;
        Defense = 0;
        Speed = 0;
        DefaultLevel = 0;        
        IsCombined = 0;
        NextEvolutionLevel = 0;
        NextEvoNo = 0;
		DefaultSkills = new unsigned int[MaxMove];
		DefaultSkills[0] = 0;
		DefaultSkills[1] = 0;
		DefaultSkills[2] = 0;
		DefaultSkills[3] = 0;
		Spesies = new char [MaxSpesiesLength];
		Spesies[0] = 'U';
		Spesies[1] = 'n';
		Spesies[2] = 'k';
		Spesies[3] = 'n';
		Spesies[4] = 'o';
		Spesies[5] = 'w';
		Spesies[6] = 'n';
		Spesies[7] = '\0';
}

//Constructor dengan Parameter
Monster::Monster (unsigned int _MonsterNumber, char* _Spesies, ElemenType _Elemen0, ElemenType _Elemen1, unsigned int _HP, unsigned int _Attack, unsigned int _Defense, unsigned int _Speed, unsigned int _DefaultLevel, unsigned int* _DefaultSkills, unsigned int _IsCombined, unsigned int _NextEvolutionLevel, unsigned int _NextEvoNo): MaxSpesiesLength(60), MaxMove(4) {
        Age = 0;
        MonsterNumber = _MonsterNumber;
        Elemen0 = _Elemen0;
        Elemen1 = _Elemen1;
        HP = _HP;		
        Attack = _Attack;
        Defense = _Defense;
        Speed = _Speed;
        DefaultLevel = _DefaultLevel;        
        IsCombined = _IsCombined;
        NextEvolutionLevel = _NextEvolutionLevel;
        NextEvoNo = _NextEvoNo;		
		int i;
		Spesies = new char[MaxSpesiesLength];
		for (i=0;i<MaxSpesiesLength;i++) {
			this->Spesies[i] = _Spesies[i];
		}	
		
		DefaultSkills = new unsigned int[MaxMove];
		for (i=0;i<MaxMove;i++) {
			this->DefaultSkills[i] = _DefaultSkills[i];
		}			
}

//Copy Constructor
Monster::Monster(const Monster& M): MaxSpesiesLength(M.MaxSpesiesLength), MaxMove(M.MaxMove) {
    this->Age = M.Age;
    this->MonsterNumber = MonsterNumber;       
    this->Elemen0 = M.Elemen0;
    this->Elemen1 = M.Elemen1;
    this->HP = M.HP;
    this->Attack = M.Attack;
    this->Defense = M.Defense;
    this->Speed = M.Speed;
    this->DefaultLevel = M.DefaultLevel;
    this->IsCombined = M.IsCombined;
    this->NextEvolutionLevel = M.NextEvolutionLevel;
    this->NextEvoNo = M.NextEvoNo;
	
	//this->MaxSpesiesLength = M.MaxSpesiesLength;
	Spesies = new char[MaxSpesiesLength];
	for (int i=0;i<MaxSpesiesLength;i++) {
		this->Spesies[i] = M.Spesies[i];
	}
	
	//this->MaxMove = M.MaxMove;
	DefaultSkills = new unsigned int[MaxMove];
	for (int i=0;i<MaxMove;i++) {
		this->DefaultSkills[i] = M.DefaultSkills[i];
	}
	
}


//Operator Assignment
Monster Monster::operator= (const Monster& M) {
	//this->MaxSpesiesLength = M.MaxSpesiesLength;
    //this->MaxMove = M.MaxMove;
    
    delete [] Spesies;
    delete [] DefaultSkills;
    this->Spesies = new char[M.MaxSpesiesLength];
    this->DefaultSkills = new unsigned int[M.MaxMove];
    
    this->Age = M.Age;
    this->MonsterNumber = MonsterNumber;       
    this->Elemen0 = M.Elemen0;
    this->Elemen1 = M.Elemen1;
    this->HP = M.HP;
    this->Attack = M.Attack;
    this->Defense = M.Defense;
    this->Speed = M.Speed;
    this->DefaultLevel = M.DefaultLevel;
    this->IsCombined = M.IsCombined;
    this->NextEvolutionLevel = M.NextEvolutionLevel;
    this->NextEvoNo = M.NextEvoNo;
	
	for (int i=0;i<MaxSpesiesLength;i++) {
		this->Spesies[i] = M.Spesies[i];
	}
		
	for (int i=0;i<MaxMove;i++) {
		this->DefaultSkills[i] = M.DefaultSkills[i];
	}
	
return *this;
}

//Destructor
Monster::~Monster() {
	delete [] Spesies;
	delete [] DefaultSkills;
}


unsigned int Monster::getMonsterNumber()
{
	return MonsterNumber;
}
char* Monster::getSpesies()
{
	return Spesies;
}

ElemenType Monster::getElemen0()
{
	return Elemen0;
}

ElemenType Monster::getElemen1()
{
	return Elemen1;
}

unsigned int Monster::getHP()
{
	return HP;
}

unsigned int Monster::getAttack()
{
	return Attack;
}

unsigned int Monster::getDefense()
{
	return Defense;
}

unsigned int Monster::getSpeed()
{
	return Speed;
}

unsigned int Monster::getDefaultLevel()
{
	return DefaultLevel;
}

unsigned int Monster::getDefaultSkills1()
{
	return DefaultSkills[0];
}

unsigned int Monster::getDefaultSkills2()
{
	return DefaultSkills[1];
}

unsigned int Monster::getDefaultSkills3()
{
	return DefaultSkills[2];
}

unsigned int Monster::getDefaultSkills4()
{
	return DefaultSkills[3];
}

unsigned int Monster::getIsCombined()
{
	return IsCombined;
}

unsigned int Monster::getNextEvolutionLevel()
{
	return NextEvolutionLevel;
}

unsigned int Monster::getNextEvoNo()
{
	return NextEvoNo;
}

void Monster::tulisMonster () {
	printf("\n\nNomor: %d\nNama: %s\nElemen: %d\nElemen2: %d\nHP: %d\nAttack: %d\nDefense %d\nSpeed: %d\nDefault Level: %d\nDefault Skill: {%d,%d,%d,%d}\nIsCombine: %d\nNextEvoLevel: %d\nNextEvoNo: %d\n", MonsterNumber, Spesies, Elemen0, Elemen1, HP, Attack, Defense, Speed, DefaultLevel, DefaultSkills[0], DefaultSkills[1], DefaultSkills[2], DefaultSkills[3], IsCombined, NextEvolutionLevel, NextEvoNo);	
}