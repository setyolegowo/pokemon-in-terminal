/* ************************************************************************** */
/*                                PROGRAM UTAMA                               */
/* ************************************************************************** */

#include "pokeranch.h"

int main()
{
    /* *** KAMUS *** */
    PokeRanch Pokeranch;
    
    /* *** ALGORITMA *** */
    Pokeranch.Start();
    
    return 0;
}