#include <iostream>
#include <cstdlib>
#include "itemtype.h"

ItemType::ItemType() : MaxNameLength(12) {

}

ItemType::ItemType(int _IndeksItemType, char *_Name, string _Description) : MaxNameLength(12) {
	Name = new char[MaxNameLength+1];
	IndeksItemType = _IndeksItemType;
	for (int i=0;i<=MaxNameLength;i++)
	{	
		Name[i]=_Name[i];
	}
	Description = _Description;
}

ItemType::~ItemType() {
	delete [] Name;
}

ItemType::ItemType(const ItemType& IT) : MaxNameLength(IT.MaxNameLength) {
	Name = new char[MaxNameLength+1];
	IndeksItemType = IT.IndeksItemType;
	for (int i=0;i<=MaxNameLength;i++)
	{	
		Name[i]=IT.Name[i];
	}
	Description = IT.Description;
}

ItemType& ItemType::operator= (const ItemType& IT) {
	// delete [] Name;
	// Name = new char[MaxNameLength+1];
	// IndeksItemType = IT.IndeksItemType;
    // std::cout << "DEBUG 1\n";
    // system("pause");
	// for (int i=0;i<=MaxNameLength;i++)
	// {	
		// Name[i] = IT.Name[i];
        // std::cout << "DEBUG 1.1\n";
	// }
    // std::cout << "DEBUG 2\n";
    // system("pause");
	// Description = IT.Description;
    // std::cout << "DEBUG 3\n";
    // system("pause");
	return *this;
}

char* ItemType::GetName() {
	return Name;
}

int ItemType::GetIndeks() {
	return IndeksItemType;
}

string ItemType::GetDesc() {
	return Description;
}

void ItemType::SetIndeks(unsigned int Idx) {
	IndeksItemType = Idx;
}

void ItemType::PrintDescription() {
	cout << "Description : " << Description << endl;
}