/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : itemtype.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __ITEMTYPE_H
#define __ITEMTYPE_H
#include <iostream>
#include <string>
using namespace std;

class ItemType
{
    private:
        const unsigned char MaxNameLength;
        unsigned int IndeksItemType;
        char *Name;
        string Description;
    public:
        ItemType();
        ~ItemType();
		ItemType(int, char*, string);
        ItemType(const ItemType&);
        ItemType& operator= (const ItemType&);
        
        // Getter Setter
		char* GetName();
		int GetIndeks();
		void SetIndeks(unsigned int);
		string GetDesc();
        
        // Operasi lain
        void PrintDescription();
};

#endif // __ITEMTYPE_H