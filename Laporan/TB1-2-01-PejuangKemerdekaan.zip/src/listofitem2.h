/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : listofitem.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
 
#ifndef __LISTOFITEM_H
#define __LISTOFITEM_H

// #include <list>
#include "item.h"

class ListOfItem
{
    public:
        // list<Item> tabelItem;
		Item *tabelItem;
        ListOfItem();
        ~ListOfItem();
        ListOfItem(const ListOfItem&);
        ListOfItem& operator= (const ListOfItem&);
        void ReadFromFile();
		int GetNItem();
	private :
		const unsigned short MaxItemList;
		int nItem;
		
};

#endif // __LISTOFITEM_H