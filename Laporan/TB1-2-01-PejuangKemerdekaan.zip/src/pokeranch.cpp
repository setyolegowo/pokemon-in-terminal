/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : pokeranch.cpp
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Kamis, 14 Maret 2013
 * Deskripsi            : 
 * - 
 */

#include <iostream>
#include "pokeranch.h"

using std::cout;
using std::cin;
using std::endl;

#include "mynamespace.cpp"

PokeRanch::PokeRanch()
{
    listSkill.ReadFromFile();
    listItem.ReadFromFile();
    // listMonster.ReadFromFile(); // <-- kayanya gak usah
    // listPlayer.ReadFromFile();
    // area.???
}
PokeRanch::~PokeRanch()
{
    listSkill.ListOfSkill::~ListOfSkill();
    listItem.ListOfItem::~ListOfItem();
    listPlayer.ListOfPlayer::~ListOfPlayer();
    // area.Area::~Area();
}
void PokeRanch::Start()
{
	bool Exit = false;
    unsigned char state = 255; // State maksudnya adalah posisi
    char user_input[255];
    char GetName[8];
    unsigned char command_respon = 255;
    unsigned char BuildingNumber = 0;
    char building[13];
    int i, num;
    Player Trainer;
    
    while(!Exit)
    {
        // Penampilan di depan layar
        switch(state)
        {
            case 0 : // Tampilan pemain pertama kali bermain
                i = 0;
            case 1 : // Tampilan pemain pertama kali bermain tampilan selanjutnya
                // -> Menampilkan story per langkah
                interface::BeginStory(i);
                interface::show_info(int(command_respon));
                // -> Menampilkan tampilan permintaan input
                interface::Input();
                cin.getline(user_input,255);
                break;
            case 2 : // Tampilan di rumah.
                // -> Menampilkan gambar rumah
                interface::Home();
                interface::show_nonBattle(int(command_respon));
                // -> Menampilkan tampilan permintaan input
                interface::Input2();
                cin.getline(user_input,255);
                break;
            case 3 :
                // -> Menampilkan gambar kota (hanya gambar statis).
                interface::City();
                interface::show_nonBattle(int(command_respon));
                // -> Menampilkan tampilan permintaan input
                interface::Input2();
                cin.getline(user_input,255);
                break;
            case 4 :
                // -> Menampilkan gambar combinatorium
                interface::Combinatorium();
                interface::show_nonBattle(int(command_respon));
                // -> Menampilkan tampilan permintaan input
                interface::Input2();
                cin.getline(user_input,255);
                break;
            case 5 :
                // -> Menampilkan gambar stadium
                interface::Stadium();
                interface::show_nonBattle(int(command_respon));
                // -> Menampilkan tampilan permintaan input
                interface::Input2();
                cin.getline(user_input,255);
                break;
            default: // Default adalah menu tampilan utama
                // -> Menampilkan tampilan utama
                interface::start_game();
                interface::show_info(int(command_respon));
                // -> Menampilkan tampilan permintaan input
                interface::Input();
                cin.getline(user_input,255);
                break;
        }
        
        // Proses input
        switch(state)
        {
            case 0: 
            case 1: // Pemberian cerita awal
                command_respon = input_manager::getNoCommand(user_input);
                if(command_respon > 0) {
                    if((command_respon >= 3) && (command_respon <= 5)) {
                        if(command_respon == 3) {
                            command_respon = 3;
                        } else if(command_respon == 4) {
                            Exit = true;
                        } else {
                            if(i < 26) {
                                i++;
                                state = 1;
                            } else {
                                // Membuat file-file pengguna (player, monster-player, item)
                                i = 0; // Reset
                                state = 2; // Goto Home
                            }
                            command_respon = 255;
                        }
                    } else
                        command_respon = 1; // berarti menggunakan komando yang lain
                } else
                    command_respon = 1;
                break;
            case 2: // Di bangunan HOME
                command_respon = input_manager::getNoCommand(user_input);
                if(command_respon > 0) {
                    if(((command_respon >= 6) && (command_respon <= 8)) || ((command_respon >= 2) && (command_respon <= 4))) {
                        switch(command_respon)
                        {
                            case 2:
                                // Jika nama pengguna yang di load ditemukan, game reset dan meload nama pengguna tersebut
                                break;
                            case 3:
                                // Tampilkan help
                                command_respon = 2;
                                break;
                            case 4:
                                Exit = true;
                                break;
                            case 6:
                                // Waktu bertambah.
                                // Restore HP dan stat monster-player
                                break;
                            case 7:
                                // Menyimpan data pengguna, menulis ke file.
                                break;
                            case 8:
                                state = 3;
                                command_respon = 255;
                                // Pindah state ke kota.
                                break;
                        }
                    } else
                        command_respon = 1; // berarti menggunakan komando yang lain
                } else
                    command_respon = 1;
                break;
            case 3: // State 3 adalah state di kota, tapi terbatas (Hanya bisa ke HOME atau STORE)
                command_respon = input_manager::getNoCommand(user_input);
                if(command_respon > 0) { // Menerima: 3, 9, 10, 11, 12, 13, 14, 15, 16, 17
                    if((command_respon == 3) || (command_respon == 4) || ((command_respon >= 9) && (command_respon <= 18))) {
                        if(command_respon == 3) {
                            // Menampilkan HELP
                            num = input_manager::getNumberN(user_input,2);
                            if(num == 1)
                                command_respon = 3;
                            else if(num == 2)
                                command_respon = 4;
                            else
                                command_respon = 1;
                        } else if(command_respon == 4) {
                            // Keluar dari permainan
                            Exit = true;
                        } else {
                            switch(command_respon)
                            {
                                case 9: // Melakukan teleport ke suatu nama bangunan
                                    input_manager::getSecond(user_input,building,13);
                                    if(building[0] == 0)
                                        command_respon = 1;
                                    else {
                                        BuildingNumber = input_manager::getNoBuilding(building);
                                        switch(BuildingNumber)
                                        {
                                            case 1:
                                            case 2:
                                            case 3:
                                            case 4:
                                            case 5:
                                                // Posisi pemain pindah sesuai dengan posisi pintu bangunan
                                                command_respon = 255;
                                                break;
                                            default: // Maka nomor bangunan tidak terdefinisi
                                                command_respon = 1;
                                                break;
                                        }
                                    }
                                    break;
                                case 10: // Melakukan gerak
                                case 11: // Menampilkan list monster
                                case 12: // Menampilkan list party
                                case 13: // Menampilkan list item
                                case 14: // Menampilkan status pemain (Nama pemain, Money, Win, Lose, SumOfDay, DayOrNight)
                                case 15: // Melakukan set dari nomor-list-monster ke no-party pertama pemain
                                case 16: // Menukar posisi party [1..6]
                                case 17: // Menghapus monster dari list-monster-pemain. Hati2 saat monster tersebut ada dalam party.
                                    break;
                                case 18:
                                    // Jika posisinya memungkinkan maka masuk ke dalam bangunan.
                                    // Teleport bisa ke titik teleport yang sedang diinjaknya.
                                    // Pertama, deteksi apakah titik teleport tersebut milik siapa, atau bukan milik siapa2
                                    // Lalu, pindah ke state bangunan tersebut.
                                    switch(BuildingNumber)
                                    {
                                        case 1:
                                            state = 4;
                                            break;
                                        case 2:
                                        case 3:
                                            break;
                                        case 4:
                                            state = 5;
                                            break;
                                        case 5:
                                            break;
                                    }
                                    command_respon = 255;
                                    break;
                            }
                        }
                    } else
                        command_respon = 1; // berarti menggunakan komando yang lain
                } else
                    command_respon = 1;
                break;
            case 4: // State 4, trainer berada di Combinatorium
                command_respon = input_manager::getNoCommand(user_input);
                if(command_respon > 0) { // Menerima: 3, 4, 8, 25
                    if(command_respon == 3) {
                        command_respon = 5;
                    } else if(command_respon == 4) {
                        Exit = true;
                    } else if(command_respon == 8) {
                        state = 3;
                        command_respon = 255;
                    } else if(command_respon == 25) {
                        // Melakukan proses kombinasi...
                    } else
                        command_respon = 1; // berarti menggunakan komando yang lain
                } else
                    command_respon = 1;
                break;
            case 5: // State 5, trainer berada di stadium
                command_respon = input_manager::getNoCommand(user_input);
                if(command_respon > 0) { // Menerima: 3, 4, 8, 26
                    if(command_respon == 3) {
                        command_respon = 6;
                    } else if(command_respon == 4) {
                        Exit = true;
                    } else if(command_respon == 8) {
                        state = 3;
                        command_respon = 255;
                    } else if(command_respon == 26) {
                        // Melakukan proses battle...
                    } else
                        command_respon = 1; // berarti menggunakan komando yang lain
                } else
                    command_respon = 1;
                break;
            default: // Default adalah bagian penerima input
                command_respon = input_manager::getNoCommand(user_input);
                if(command_respon > 0) {
                    if((command_respon >= 1) && (command_respon <= 4)) {
                        if(command_respon == 1) {
                            input_manager::getSecond(user_input, GetName, 7);
                            if(!listPlayer.IsOnTable(GetName)) {
                                if(GetName[0] == '\0')
                                    command_respon = 4; // Teks tidak masuk akal
                                else {
                                    command_respon = 255;
                                    state = 0;
                                }
                            } else {
                                command_respon = 5; // User ada
                            }
                            // Jika user lama, beritahu ke layar
                            command_respon = 255; // Reset command_respon
                        } else if(command_respon == 2) {
                            // Mencari apakah user terdaftar atau tidak
                            // Jika ada, maka load databasenya dan pindah state terakhir pengguna.
                            // Jika tidak ada, beritahu ke layar
                            command_respon = 255; // Reset command_respon
                        } else if(command_respon == 3) {
                            command_respon = 2;
                        } else // pasti command_respon == 4
                            Exit = true;
                    } else
                        command_respon = 1; // berarti menggunakan komando yang lain
                } else
                    command_respon = 1;
                break;
        }
    }
}