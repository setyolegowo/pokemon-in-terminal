/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : skill.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __SKILL_H
#define __SKILL_H
 
#include "elementype.h"
#include "efektype.h"

class Skill
{
    private:
        const unsigned char MaxNameLength;
        const unsigned char PPMax;
        unsigned int SkillNumber;
        char *Name;
        enum TargetType {Self, Foo} Target;
        ElemenType Element;
        ElemenType *StrWeak;
        short Power;
        enum PE {HP, Attack, Defense, Speed, Accuracy} PowerEffect;
        unsigned char AccuracySkill;
        EffectType Effect;
        float ProsenEfek;
    public:
        Skill();
        Skill(unsigned int, char*, int, int, int*, short, unsigned char, unsigned char, int, float);
		Skill(unsigned int, char*, Skill::TargetType, ElemenType, ElemenType*, short int, unsigned char, unsigned char, EffectType, float);
        ~Skill();
        Skill(const Skill&);
        Skill &operator= (Skill&);
		unsigned char GetPPMax();
		unsigned int GetSkillNumber();
		char* GetName();
		int GetTarget();
		ElemenType GetElement();
		ElemenType GetStrWeak(int);
		short GetPower();
		int GetPowerEfect();
		unsigned char GetAccuracy();
		EffectType GetEffectType();
		float GetProsenEfek();
};

#endif // __SKILL_H