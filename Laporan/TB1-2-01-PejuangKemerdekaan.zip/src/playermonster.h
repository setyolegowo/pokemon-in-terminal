/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : playermonster.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __PLAYERMONSTER_H
#define __PLAYERMONSTER_H

class PlayerMonster: public Monster
{
    private:
        const unsigned int MaxNameLength;
        unsigned int MonsterNumber;
        char Name[MaxNameLength];
        unsigned int CurAge;
        unsigned int CurLevel;
        unsigned int CurExp;
        unsigned int TotalExp;
        unsigned short IncHP;
        unsigned short HP;
        unsigned short IncAttack;
        unsigned short IncDefense;
        unsigned short IncSpeed;
        Skill Skills[MaxMove];
        int PPOfSkills[MaxMove];
        EffectType StatusEffect;
    public:
        PlayerMonster();
        ~PlayerMonster();
        PlayerMonster(const PlayerMonster&);
        PlayerMonster operator=(const PlayerMonster&);
        void ChangeName(char*);
        void AddExp(unsigned int);
        void IncLevel();
        void RestoreHP();
        void IncState(char,char);
        void RestorePP(char);
		
		unsigned int getMonsterNumber();
		char* getName();
		unsigned int getCurAge();
		unsigned int getcurLevel();
		unsigned int getCurExp();
		unsigned int getTotalExp();
		unsigned short getIncHP();
		unsigned short getHP();
		unsigned short getIncAttack();
		unsigned short getIncDefense();
		unsigned short getIncSpeed();
		Skill* getSkills();
		int* getPPOfSkills();
		EffectType getStatusEffect();
}

#endif // __PLAYERMONSTER_H