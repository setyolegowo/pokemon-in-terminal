/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : point.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 // Created By Fawwaz Muhammad

 #include <iostream>
 #include "area.h"

using namespace std;

Area::Area():MaxUnstapablePoint(100)
{	
	int size;
	Width=39;
	Height=9;
	size = Width*Height;
	area = new unsigned char[size];
	
	// Set nilai default array
	for (int i = 0; i <= size; ++i)
	{
		area[i]=0;
	}

	PlayerPosition.SetX(5);
	PlayerPosition.SetY(5);
	PlayerPositionPlace = 0;
}

Area::~Area()
{
	delete area;
}

Area::Area(const Area& A):MaxUnstapablePoint(A.MaxUnstapablePoint)
{
	int size;
	Width=A.Width;
	Height=A.Height;
	size = Width*Height;
	area = new unsigned char[size];
	
	// Set nilai default array
	for (int i = 0; i <= size; ++i)
	{
		area[i]=A.area[i];
	}
	Point p=A.PlayerPosition;
	PlayerPosition.SetX(p.GetX());
	PlayerPosition.SetY(p.GetY());
	PlayerPositionPlace = A.PlayerPositionPlace;
}

Area& Area::operator=(Area& A)
{
	int size;
	Width=A.Width;
	Height=A.Height;
	size = Width*Height;
	area = new unsigned char[size];
	
	// Set nilai default array
	for (int i = 0; i <= size; ++i)
	{
		area[i]=A.area[i];
	}

	PlayerPosition.SetX(A.PlayerPosition.GetX());
	PlayerPosition.SetY(A.PlayerPosition.GetY());
	PlayerPositionPlace = A.PlayerPositionPlace;
	return *this;
}

unsigned char Area::GetWidth(){return Width;}
unsigned char Area::GetHeight(){return Height;}
void Area::SetWidth(unsigned char W){ Width=W;}
void Area::SetHeight(unsigned char H){ Height=H;}


int Area::ConvertPointToIdxArea(Point& P)
{
	return GetWidth()*P.GetY()+P.GetX();
}


Point Area::ConvertIdxAreaToPoint(int I)
{
	Point P;
	P.SetY(I / GetWidth());
	P.SetX(I % GetWidth());
	return P;
}


int Area::GetMaxUnstapablePoint()const{return MaxUnstapablePoint;}


bool Area::UpdatePlayerPosition(unsigned char direction,unsigned char steps)
{
	unsigned char tempx,tempy,tempidx;
	tempx=PlayerPosition.GetX();
	tempy=PlayerPosition.GetY();
	tempidx=ConvertPointToIdxArea(PlayerPosition);
	switch(direction)
	{
		case 1:
			// cek kondisi dulu apakah valid moves
			if ((tempy-steps)>GetHeight())
			{
				cout << "Invalid moves" <<endl;
				return false;
				/* code */
			}else{
				area[tempidx]=0;
				PlayerPosition.IncTop(steps);
				return true;
			}
			break;
		case 2:
			if ((tempx+steps)>GetWidth())
			{
				cout << "Invalid moves" <<endl;
				return false;
				/* code */
			}else{
				area[tempidx]=0;
				PlayerPosition.IncRight(steps);
				return true;
			}
			break;
		case 3:
			if ((tempy+steps)>GetHeight())
			{
				cout << "Invalid moves" <<endl;
				return false;
				/* code */
			}else{
				area[tempidx]=0;
				PlayerPosition.IncBottom(steps);
				return true;
			}
			break;
		case 4:
			if ((tempx-steps)>GetWidth())
			{
				cout << "Invalid moves" <<endl;
				return false;
				/* code */
			}else{
				area[tempidx]=0;
				PlayerPosition.IncLeft(steps);
				return true;
			}
			break;
		default:
			break;
	}
}

// bool* Area::GetArea(){return area;}
// void Area::SetArea(bool &A){area=A;}