/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : city.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __CITY_H
#define __CITY_H

#include "home.h"
#include "store.h"
#include "combinatorium.h"
#include "stadium.h"

class City
{
    private:
        const unsigned char MaxNameLength;
        const unsigned char NBuilding;
        
        char NamaKota[MaxNameLength];
        Point TeleportPosition[NBuilding];
        HOME Home;
        STORE Store;
        COMBINATORIUM Combinatorium;
        STADIUM Stadium;
    public:
        Kota();
        ~Kota();
        Kota(const Kota&);
        Kota &operator= (Kota&);
        void PrintMap(); // Display area like map
        void FixUnstapableArea();
        virtual void PrintMap();
};

#endif // __CITY_H