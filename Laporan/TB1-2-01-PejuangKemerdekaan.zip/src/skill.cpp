/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : skill.cpp
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Kamis, 14 Maret 2013
 * Deskripsi            : 
 * - 
 */
 

#include "elementype.h"
#include "efektype.h"
#include "skill.h"
using namespace std;



Skill::Skill(): MaxNameLength(20), PPMax(4)
{
    Name = new char[MaxNameLength];
    StrWeak = new ElemenType[MaxNameLength];
}

Skill::~Skill()
{
	delete [] Name;
	delete [] StrWeak;
}

Skill::Skill(unsigned int _SkillNumber, char* _Name, int _Target, int _Element, int * _StrWeak, short _Power, unsigned char _PowerEffect, unsigned char _AccuracySkill, int _Effect, float _ProsenEfek):MaxNameLength(20), PPMax(4)
// Prekondisi: masukan adalah terdefinisi
{
    Name = new char[MaxNameLength];
    StrWeak = new ElemenType[2];
	SkillNumber=_SkillNumber;
	for (int i=0;i<=MaxNameLength;i++)
	{	
		Name[i]=_Name[i];
	}
	if(_Target == 0)
        Target = Self;
    else
        Target = Foo;
	switch(_Element)
    {
        case 1: Element = Psychic; break;
        case 2: Element = Fight; break;
        case 3: Element = Normal; break;
        case 4: Element = Water; break;
        case 5: Element = Grass; break;
        case 6: Element = Ground; break;
        case 7: Element = Flying; break;
        case 8: Element = Ice; break;
        case 9: Element = Electric; break;
        case 10: Element = Dragon; break;
    }
    switch(_StrWeak[0])
    {
        case 1: StrWeak[0] = Psychic; break;
        case 2: StrWeak[0] = Fight; break;
        case 3: StrWeak[0] = Normal; break;
        case 4: StrWeak[0] = Water; break;
        case 5: StrWeak[0] = Grass; break;
        case 6: StrWeak[0] = Ground; break;
        case 7: StrWeak[0] = Flying; break;
        case 8: StrWeak[0] = Ice; break;
        case 9: StrWeak[0] = Electric; break;
        case 10: StrWeak[0] = Dragon; break;
    }
    switch(_StrWeak[1])
    {
        case 1: StrWeak[1] = Psychic; break;
        case 2: StrWeak[1] = Fight; break;
        case 3: StrWeak[1] = Normal; break;
        case 4: StrWeak[1] = Water; break;
        case 5: StrWeak[1] = Grass; break;
        case 6: StrWeak[1] = Ground; break;
        case 7: StrWeak[1] = Flying; break;
        case 8: StrWeak[1] = Ice; break;
        case 9: StrWeak[1] = Electric; break;
        case 10: StrWeak[1] = Dragon; break;
    }
	Power=_Power;
	switch(_PowerEffect)
    {
        case 0: PowerEffect = HP; break;
        case 1: PowerEffect = Attack; break;
        case 2: PowerEffect = Defense; break;
        case 3: PowerEffect = Speed; break;
        case 4: PowerEffect = Accuracy; break;
    }
	AccuracySkill=_AccuracySkill;
	switch(_Effect)
    {
        case 0: Effect = NoEffect; break;
        case 1: Effect = Paralyz; break;
        case 2: Effect = Poison; break;
        case 3: Effect = BadPoison; break;
        case 4: Effect = Burn; break;
        case 5: Effect = Freeze; break;
        case 6: Effect = Sleep; break;
    }
	ProsenEfek=_ProsenEfek;
}

Skill::Skill(const Skill& S):MaxNameLength(S.MaxNameLength),PPMax(S.PPMax)
{
	SkillNumber=S.SkillNumber;
	Name = new char[MaxNameLength];
	for (int i=0;i<=MaxNameLength;i++)
	{	
		Name[i]=S.Name[i];
	}
	Target=S.Target;
	Element=S.Element;
	StrWeak = new ElemenType[2];
	for (int i=0;i<=1;i++)
	{	
		StrWeak[i]=S.StrWeak[i];
	}
	Power=S.Power;
	PowerEffect=S.PowerEffect;
	AccuracySkill=S.AccuracySkill;
	Effect=S.Effect;
	ProsenEfek=S.ProsenEfek;

}

Skill& Skill::operator= (Skill& S)
{
	delete [] Name;
    SkillNumber=S.SkillNumber;
	Name = new char[MaxNameLength];
	for (int i=0;i<=MaxNameLength;i++)
	{	
		Name[i]=S.Name[i];
	}
	Target=S.Target;
	Element=S.Element;
	StrWeak = new ElemenType[2];
	for (int i=0;i<=1;i++)
	{	
		StrWeak[i]=S.StrWeak[i];
	}
	Power=S.Power;
	PowerEffect=S.PowerEffect;
	AccuracySkill=S.AccuracySkill;
	Effect=S.Effect;
	ProsenEfek=S.ProsenEfek;
	return *this;
}
unsigned char Skill::GetPPMax()
{
	return (unsigned char) PPMax;
}

unsigned int Skill::GetSkillNumber()
{
	return SkillNumber;
}
char* Skill::GetName()
{
	return Name;
}

int Skill::GetTarget()
{
	return Target;
}

ElemenType Skill::GetElement()
{
	return Element;
}

ElemenType Skill::GetStrWeak(int i)
{
	if(i == 1)
        return StrWeak[0];
    else if(i == 2)
        return StrWeak[1];
    else
        throw(4);
}

short Skill::GetPower()
{
	return Power;
}

int Skill::GetPowerEfect()
{
	return PowerEffect;
}

unsigned char Skill::GetAccuracy()
{
	return AccuracySkill;
}

EffectType Skill::GetEffectType()
{
	return Effect;
}

float Skill::GetProsenEfek()
{
	return ProsenEfek;
}