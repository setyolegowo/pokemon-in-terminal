/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : listofitem.cpp
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */

#include <list>
#include <iostream>
#include <fstream>
#include "listofitem.h"
// using namespace std;

ListOfItem::ListOfItem() {
}

ListOfItem::~ListOfItem() {
    tabelItem.clear();
    tabelItem.~list();
}

ListOfItem::ListOfItem(const ListOfItem& LOI) {
    
}

ListOfItem& ListOfItem::operator= (ListOfItem& LOP) {
    return *this;
}

void ListOfItem::ReadFromFile()
{
    ifstream myfile("item/item.txt",ifstream::in);
    
    tabelItem.clear();
    if(myfile.is_open()) {
        while(myfile.good())
        {
            char cur_stream[100];
            char nama[12];
            int i = 0;
            unsigned int no;
            
            myfile.getline(cur_stream,100);
            // => Get Number of item
            no = 0;
            while(cur_stream[i] != ' ')
            {
                no = 10*no + (cur_stream[i] - '0');
                i++;
            }
            i++; // Lewati karakter spasi
            
            // => Get nama item
            int j = 0;
            while(cur_stream[i] != ' ')
            {
                nama[j] = cur_stream[i];
                i++;
                j++;
            }
            while(j < 12) {
                nama[j] = '\0';
                j++;
            }
            i++; // Lewati karakter spasi
            
            // => Get Type
            unsigned int n = cur_stream[i] - '0';
            i++;
            i++;
            
            // => Get Price
            unsigned int Price = 0;
            while(cur_stream[i] != ' ') {
                Price = 10*Price + (cur_stream[i] - '0');
                i++;
            }
            i++;
            
            // => Get Value
            unsigned int Value = 0;
            while(cur_stream[i] != ',') {
                Value = 10*Value + (cur_stream[i] - '0');
                i++;
            }
            
            // Masukkan ke tipe item
            Item tItem(no,nama,n,Price,Value);
            
            // Masukkan ke list
            tabelItem.push_back(tItem);
        }
    } else
        throw(2);
    
    myfile.close();
}