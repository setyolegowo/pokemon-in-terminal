/* ************************************************************************** */
/*                                  POKERANCH                                 */
/* ************************************************************************** */

/*
 * Nama / NIM           : Lubis Sucipto / 13511025
 *                        Muhammad Rizky W / 13511037
 *                        Andreas Dwi Nugroho / 13511051
 *                        Setyo Legowo / 13511071
 *                        Fawwaz Muhammad / 13511083
 *                        Asep Saepudin / 13511093
 * Nama File            : player.h
 * Bahasa               : C++
 * Compiler             : g++
 * Tanggal Diperbaharui : Selasa, 5 Maret 2013
 * Deskripsi            : 
 * - 
 */
 
#ifndef __PLAYER_H
#define __PLAYER_H

#include <list>
#include "monster.h"
#include "item.h"
struct lItem{
    unsigned char noItem;
    unsigned char nItem;
};
class Player
{
    private:
        const unsigned char MaxNameLength;
        const unsigned char MaxPartyMonster;
        unsigned int PlayerNumber;
        char *Name;
        unsigned int SumOfDays;
        unsigned char DayOrNight;
        unsigned int Money;
        unsigned int Win;
        unsigned int Lose;
		std::list<lItem> ListPlayerItem;
		std::list<unsigned short> ListPlayerMonster;
		std::list<unsigned short> ListPartyMonster;
    public:
        Player();
        ~Player();
        Player(const Player&);
        Player operator=(const Player&);
        unsigned char GetMaxNameLength();
        unsigned char GetMaxPartyMonster();
        void ChangeName(char*);
        void AddListItem(unsigned char, unsigned char);
        void DelListItem(unsigned short, unsigned char);
        void AddMonster(unsigned short);
        void DelMonster(unsigned short);
        void IncMoney(unsigned int);
        void DecMoney(unsigned int);
        void ChangeParty(unsigned char, unsigned char);
        void AddOneWin();
        void AddOneLose();
        void ChangePlayerNumber(unsigned int);
};

#endif // __PLAYER_H